
// This service has been removed to ensure zero-latency, offline reliability 
// in noisy paintball event environments without stable reception.
export {};
